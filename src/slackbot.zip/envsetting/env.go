package envsetting

type EnvConfig struct {
	// Port is server port to be listened.
	Port string `envconfig:"PORT" default:"3000"`

	// BotToken is bot user token to access to slack API.
	BotToken string `envconfig:"BOT_TOKEN" required:"true"`

	// VerificationToken is used to validate interactive messages from slack.
	VerificationToken string `envconfig:"VERIFICATION_TOKEN" required:"true"`

	// BotID is bot user ID.
	BotID string `envconfig:"BOT_ID" required:"true"`

	// ChannelID is slack channel ID where bot is working.
	// Bot responses to the mention in this channel.
	ChannelID string `envconfig:"CHANNEL_ID" required:"true"`
}

type TwitterConfig struct {
	ConfKey     string
	ConfSecret  string
	TokenKey    string
	TokenSecret string
}

type Interpark struct {
	ID string
	PW string
}

// 1. 슬랙과 연결 하기
func Envconfig(env EnvConfig) EnvConfig {

	//회사계정

	env.Port = "9293"
	env.BotID = "U6HG739L2"
	//env.botToken = "xoxb-220418545797-9yd5Um7A89gvPL1MwVANg0Mu"
	env.BotToken = "xoxb-221551111682-JaW84MVJOtNjVsLXkbDzpdoN"
	//env.ChannelID = "C6GJV3WUE" //ITNEWS 채널
	env.ChannelID = "C54J4EXRA" //general 채널
	//env.ChannelID = "C6JTFTKMH" // bot test 채널(아이티채널이 너무더러움)
	env.VerificationToken = "aK5RssafjnirjSUp9IlTFUUw"

	return env
}

// 이걸 json으로 만들어서 불러와서 적용시키는것도 괜찮지 않을까?
// 토큰, 계정정보, 불러올 주소 등등
// 2. 트위터와 연결하기
func Twitterconfing(env TwitterConfig) TwitterConfig {

	env.ConfKey = "cNDqz8JddpeG994u70PVghb3I"
	env.ConfSecret = "fb7GKH9UHD177olqNjw9Q4EcDqz4RQfxzJcD0mcDPKHv67oYoB"
	env.TokenKey = "882241241848594434-uU7kuYvMg1ipZWVwfpqtezswvD231Ad"
	env.TokenSecret = "JIDl0uTlH0KwqBTvyD10wwZmQzUlXjp8s4wYRQMtIoFoU"

	return env
}

// 3. 깃허브와 연결하기
func Gitconfig() string {

	return "72874b40b9ba2b8afefc11dd6201634b4043ffd2"
}

// 4. 회사에 로그인하기
func InterparkLogin(i Interpark) Interpark {

	i.ID = "n17286"
	i.PW = "rnfnal12!!"

	return i

}
